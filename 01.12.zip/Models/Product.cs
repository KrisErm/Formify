﻿using System;

namespace Formify.Models
{
    public class Product
    {
        public long Id { get; set; }                // BIGSERIAL
        public string Name { get; set; } = null!;   // name
        public string? Description { get; set; }    // description
        public decimal Price { get; set; }          // price numeric(10,2)

        public byte[]? ImageData1 { get; set; }     // image_data
        public string? ImageName1 { get; set; }     // image_name
        public string? ImageContentType1 { get; set; }// image_content_type

        public byte[]? ImageData2 { get; set; }
        public string? ImageName2 { get; set; }
        public string? ImageContentType2 { get; set; }

        public byte[]? ImageData3 { get; set; }
        public string? ImageName3 { get; set; }
        public string? ImageContentType3 { get; set; }

        public bool IsActive { get; set; } = true;  // is_active
        public DateTime CreateDate { get; set; }    // create_date
        public DateTime UpdateDate { get; set; }    // update_date
    }
}
