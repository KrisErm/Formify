using System;
using System.IO;
using System.Collections.Generic;
using System.Threading.Tasks;
using Formify.Data;
using Formify.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Formify.Pages.Catalog
{
    [Authorize(Roles = "admin")]
    public class CreateModel : PageModel
    {
        private readonly AppDbContext _context;

        public CreateModel(AppDbContext context)
        {
            _context = context;
        }

        [BindProperty]
        public Product Input { get; set; } = new();

        // ����: IFormFile? ImageFile
        [BindProperty]
        public List<IFormFile>? ImageFiles { get; set; }

        public void OnGet()
        {
            Input.IsActive = true;
        }

        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
                return Page();

            if (ImageFiles != null && ImageFiles.Count > 0)
            {
                for (int i = 0; i < Math.Min(ImageFiles.Count, 3); i++)
                {
                    var file = ImageFiles[i];
                    if (file != null && file.Length > 0)
                    {
                        using var ms = new MemoryStream();
                        await file.CopyToAsync(ms);
                        var imageData = ms.ToArray();

                        switch (i)
                        {
                            case 0:
                                Input.ImageData1 = imageData;
                                Input.ImageName1 = file.FileName;
                                Input.ImageContentType1 = file.ContentType;
                                break;
                            case 1:
                                Input.ImageData2 = imageData;
                                Input.ImageName2 = file.FileName;
                                Input.ImageContentType2 = file.ContentType;
                                break;
                            case 2:
                                Input.ImageData3 = imageData;
                                Input.ImageName3 = file.FileName;
                                Input.ImageContentType3 = file.ContentType;
                                break;
                        }
                    }
                }
            }

            Input.CreateDate = DateTime.UtcNow;
            Input.UpdateDate = DateTime.UtcNow;

            _context.Products.Add(Input);
            await _context.SaveChangesAsync();

            return RedirectToPage("Manage");
        }
    }
}
