using System;
using System.IO;
using System.Threading.Tasks;
using Formify.Data;
using Formify.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Formify.Pages.Catalog
{
    [Authorize(Roles = "admin")]
    public class EditModel : PageModel
    {
        private readonly AppDbContext _context;

        public EditModel(AppDbContext context)
        {
            _context = context;
        }

        [BindProperty]
        public Product Input { get; set; } = null!;

        [BindProperty]
        public List<IFormFile>? ImageFiles { get; set; }

        public async Task<IActionResult> OnGetAsync(long id)
        {
            var product = await _context.Products.FindAsync(id);
            if (product == null)
                return NotFound();

            Input = product;
            return Page();
        }

        public async Task<IActionResult> OnPostAsync(long id)
        {
            if (id != Input.Id)
                return NotFound();

            if (!ModelState.IsValid)
                return Page();

            var product = await _context.Products.FindAsync(id);
            if (product == null)
                return NotFound();

            product.Name = Input.Name;
            product.Description = Input.Description;
            product.Price = Input.Price;
            product.IsActive = Input.IsActive;
            product.UpdateDate = DateTime.UtcNow;

            if (ImageFiles != null && ImageFiles.Count > 0)
            {
                for (int i = 0; i < Math.Min(ImageFiles.Count, 3); i++)
                {
                    var file = ImageFiles[i];
                    if (file != null && file.Length > 0)
                    {
                        using var ms = new MemoryStream();
                        await file.CopyToAsync(ms);
                        var imageData = ms.ToArray();

                        switch (i)
                        {
                            case 0:
                                product.ImageData1 = imageData;
                                product.ImageName1 = file.FileName;
                                product.ImageContentType1 = file.ContentType;
                                break;
                            case 1:
                                product.ImageData2 = imageData;
                                product.ImageName2 = file.FileName;
                                product.ImageContentType2 = file.ContentType;
                                break;
                            case 2:
                                product.ImageData3 = imageData;
                                product.ImageName3 = file.FileName;
                                product.ImageContentType3 = file.ContentType;
                                break;
                        }
                    }
                }
            }

            await _context.SaveChangesAsync();
            return RedirectToPage("Index");
        }
    }
}