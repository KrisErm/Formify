using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Formify.Pages.Shared.Components.CartSummary
{
    public class DefaultModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
