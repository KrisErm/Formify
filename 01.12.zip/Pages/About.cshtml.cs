using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Formify.Pages
{
    public class AboutModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
